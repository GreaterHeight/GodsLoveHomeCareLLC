
var GlobalThemeOptions = {
    accent:"#077920",
    accent2:"#eab14d",
    accent3:"#eab14d",
    accent4:"#077920",
};

var GlobalAriaLabel = {
    Gotoslide:"Go to slide",
    Previousslide:"Previous slide",
    Nextslide:"Next slide",
    Tabs:"Tabs",
    Tab:"Tab ",
    Rating:"Rating",

    Previous:"Previous",
    Next:"Next",
    Close:"Close",
    LinkArrow:"Link Arrow",
    Arrow:"Arrow",

};





/** custom.js start*/
(function($){const image=new Image();image.src='data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=';image.onerror=function(){if(typeof GetWebpConvertServiceUrl!="undefined"&&$(".d-wrapper").eq(0).data("mid")){let WebpServiceUrl=GetWebpConvertServiceUrl+$(".d-wrapper").eq(0).data("mid")+"&f=png&WebP=";let LocalUrl=window.location.host;$('.content-builder img[src*=".webp"],.content-builder img[data-src*=".webp"],.content-builder [style*=".webp"],.content-builder a[href*=".webp"]').each(function(){let isImg=this.localName.toUpperCase();let url=false;if(isImg=="IMG"){url=$(this).attr("data-src")||$(this).attr("src");}else if(isImg=="A"){url=$(this).attr("href");}else{url=this.style.backgroundImage.split('"')[1];}
if(url.indexOf(LocalUrl)!=-1){url=url.split(LocalUrl)[1];};if((url.indexOf("http://")!=-1||url.indexOf("https:///")!=-1))return;url=WebpServiceUrl+encodeURIComponent(url);if(isImg=="IMG"){$(this).attr("src").indexOf(".webp")!=-1?$(this).attr("src",url):$(this).attr("data-src",url);}else if(isImg=="A"){$(this).attr("href",url);}else{this.style.backgroundImage='url('+url+')';}})}};})(jQuery);var floatingOffset=0;jQuery(".header-bg-box").each(function(){if(jQuery(this).data("height")){floatingOffset+=parseInt($(this).data("height"));}})
var defaultfloatingOffset=floatingOffset;if(jQuery(".floating-nav-scrollup").length){floatingOffset=defaultfloatingOffset=0;}
if(jQuery(window).width()<992){if(jQuery(".mobile-header").css("position")=="fixed"){floatingOffset=$(".mobile-header-replace").height()||$(".mobile-header").height();}else{floatingOffset=0;}}
jQuery(window).on("resize",function(){if(jQuery(window).width()<992){if(jQuery(".mobile-header").css("position")=="fixed"){floatingOffset=jQuery(".mobile-header-replace").height()||$(".mobile-header").height();}else{floatingOffset=0;}}else{floatingOffset=defaultfloatingOffset;}});jQuery.fn.offsetTopParent=function(parent){return $(this).offset().top+parent.scrollTop();}
var ImgLoad=function(callback,e){var imgdefereds=[];e.find('img').each(function(){var dfd=jQuery.Deferred();jQuery(this).on('load',function(){dfd.resolve();}).on('error',function(){dfd.resolve();});if(this.complete){setTimeout(function(){dfd.resolve();},1000);}
imgdefereds.push(dfd);});jQuery.when.apply(null,imgdefereds).done(function(){callback();});};(function($){"use strict";var DNG={};DNG.fixedFooter=function(){$(".fixed_footer").each(function(){var e=$(this);e.wrap("<div class=\"fixed_footer_clone\"><div class=\"fixed_footer_bottom\"></div></div>");var wh=$(window).height(),parent=e.parent().parent(),parent2=e.parent();parent.height(e.innerHeight());$(window).on("resize",function(){parent.height(e.innerHeight());e.css("max-height",$(window).height());wh=$(window).height();parent2.height($(window).scrollTop()+wh-parent.offset().top);});$(window).on('load',function(){parent.height(e.innerHeight());e.css("max-height",$(window).height());wh=$(window).height();parent2.height($(window).scrollTop()+wh-parent.offset().top);});e.addClass("active");e.css("max-height",$(window).height());parent2.height($(window).scrollTop()+wh-parent.offset().top);$(window).on("scroll",function(){parent2.height($(window).scrollTop()+wh-parent.offset().top);});});};DNG.pageLoaders=function(){$(".page-loaders").fadeOut();};DNG.floatingNav=function(){$(".header-wrap.floating-nav").each(function(){var e=$(this),top=e.data("top")!==undefined?e.data("top"):Math.max(e.offset().top,1);var floating_nav=function(){if($(window).scrollTop()>=top){if(!e.hasClass("floating-active")){if(e.hasClass("floating-nav-fade")){e.stop().css("opacity","0").animate({"opacity":"1",},500).addClass("floating-active");}else if(e.hasClass("floating-nav-slide")){e.stop().css({"opacity":"0",top:-e.height()+"px"}).animate({"opacity":"1",top:"0"},300).addClass("floating-active");}else if(e.hasClass("floating-nav-sticky")){e.addClass("floating-active");}}}else{if(e.hasClass("floating-active")){if(e.hasClass("floating-nav-fade")||e.hasClass("floating-nav-slide")){e.stop().css({"opacity":1}).removeClass("floating-active");;}}
if(e.hasClass("floating-nav-sticky")){e.removeClass("floating-active");}}};var minHeight=$("header.header_bg").height();if(minHeight==0){$(window).on("resize",function(){if(!minHeight){minHeight=$("header.header_bg").height();e.parent(".header-replace").css("min-height",minHeight);}})}
e.parent(".header-replace").css("min-height",minHeight).addClass("sticky-fixed");if(e.hasClass("floating-nav-scrollup")){var scroll=e.offset().top;var top2=top;$(window).on("scroll",function(){if($(window).scrollTop()>scroll){if($(window).scrollTop()>=top){e.addClass("floating-active");scroll=$(window).scrollTop();}
if(e.hasClass("floating-active-down")&&$(window).scrollTop()>=top){e.removeClass("floating-active-down").addClass("floating-active-up");}}else{if($(window).scrollTop()<=top2){e.removeClass("floating-active floating-active-up floating-active-down");scroll=top;return;}else if(scroll-$(window).scrollTop()>10&&$(window).scrollTop()>=top){scroll=$(window).scrollTop();e.removeClass("floating-active-up").addClass("floating-active-down");}}});top=e.height()+100+top;}
floating_nav();$(window).on("scroll",function(){floating_nav();});});};DNG.mobileheadernavbar=function(){$("body > form").append($(".mobile-header-navbar .mega-menu-wrap").addClass("mobile_menu").append("<span class='mobile_menu_close lnr lnr-cross'></span>"));if($("#wpadminbar").length!=0&&$(".mobile-header").css("position")=="fixed"){$(window).on("scroll",function(){$(".mobile-header").css("top",Math.max($("#wpadminbar").height()-$(window).scrollTop(),0));})}};DNG.pageTitle=function(){$("#page-title").each(function(){var e=$(this);if(e.data("height")==="full"){e.children(".page-title-container").innerHeight($(window).height()-e.offset().top);$(window).on("resize",function(){e.children(".page-title-container").innerHeight($(window).height()-e.offset().top);});}
e.find(".page-title-arrow").on("click",function(){jQuery('body,html').stop().animate({scrollTop:e.innerHeight()+e.offset().top-floatingOffset},($("html").css("scroll-behavior")=="smooth"?0:800));});var center=e.find(".center-v.scrolling-text");if(center.length){var con_height=center.innerHeight();var e_height=e.innerHeight();if($(".page-breadcrumbs.inset").length){e_height=e.innerHeight()-$(".page-breadcrumbs.inset").innerHeight();}
var offset_bottom=e_height-con_height-center.position().top;var e_top=e.offset().top-floatingOffset;var curr_roll=0;$(window).on("resize",function(){con_height=center.innerHeight();e_height=e.innerHeight();if($(".page-breadcrumbs.inset").length){e_height=e.innerHeight()-$(".page-breadcrumbs.inset").innerHeight();}});$(window).on("scroll",function(){if(e_top<=$(window).scrollTop()){curr_roll=$(window).scrollTop()-e_top;center.css({'transform':'translateY('+Math.min(curr_roll/2,offset_bottom)+'px)','opacity':1-(1/e_height)*(curr_roll)})}else{center.removeAttr("style")}})
if(e_top<=$(window).scrollTop()){curr_roll=$(window).scrollTop()-e_top;center.css({'transform':'translateY('+Math.min(curr_roll/2,offset_bottom)+'px)'})}}});};DNG.detailPageTitle=function(){$(".detail-pagetitle").each(function(){var e=$(this);if(e.data("height")==="full"){e.innerHeight($(window).height()-e.offset().top);$(window).on("resize",function(){e.innerHeight($(window).height()-e.offset().top);});}
e.find(".page-title-arrow").on("click",function(){jQuery('body,html').stop().animate({scrollTop:e.innerHeight()+e.offset().top-floatingOffset},($("html").css("scroll-behavior")=="smooth"?0:800));});});};DNG.pageEndAnimating=function(){if($(".page-loaders").length===0||typeof DNNapplyTypography!="undefined"){return false;}
var isAnimating=false;$('body').addClass('page-loader-changing');var alinkAnimating=function(event,t){var href=t.attr('href');if(!href){return;}
if(href.substring(0,1)=="#"){return;}
if(href.substring(0,4)!=="http"&&href.substring(0,1)!=="index.html"){return;}
if(href.split("#")[0]==window.location.href.split("#")[0]){return;}
if(href.split("#")[0]==window.location.pathname){return;}
if(href.indexOf(".jpg")!==-1||href.indexOf(".png")!==-1||href.indexOf(".gif")!==-1||href.indexOf(".bmp")!==-1){return;}
if(t.attr("class")){if(t.attr("class").indexOf("LightBox")!==-1||t.attr("class").indexOf("is-lightbox")!==-1){return;}}
if(t.hasClass("mm-title")){return;}
event.preventDefault();var newPage=href;var target=t.attr("target")?t.attr("target"):"_self";if(!isAnimating){isAnimating=true;$('body').addClass('page-is-changing');setTimeout(function(){window.open(newPage,target);if(target!=="_self"){$('body').delay(300).queue(function(){$('body').removeClass('page-is-changing').dequeue();isAnimating=false;});}else{isAnimating=false;}},300);}}
$('.dng-megamenu,.dng-mobilemenu,.page-breadcrumbs,.footer-info-box,.userMenu,.logo,.link-animate').on('click','a',function(event){alinkAnimating(event,$(this));});$('.link-animate').on('click',function(event){alinkAnimating(event,$(this));});};DNG.sidebarSticky=function(){$('.sidebar_sticky[data-sticky="on"],.sticky_media,.sidebar-sticky').each(function(){if(typeof DNNapplyTypography!="undefined"){return;}
var wpadminbar=$("#wpadminbar").length==0?0:$("#wpadminbar").height();var e=$(this),parent=e.parent(),parentbox=e.parents(".is-container,[data-sticky=parent]").eq(0),offset=e.data("offset")?e.data("offset"):0,offsetTop=wpadminbar+floatingOffset+offset,stickyEnd=parseInt(parentbox.height())+parentbox.offset().top,parenttop=parent.offset().top-offsetTop,height=e.innerHeight(),addel=0,parentwidth=parent.width(),parentboxwidth=parentbox.width();e.width(e.width());if($(".fixed-top-container").length){if($(".fixed-top-container").offset().top<e.offset().top){addel=$(".fixed-top-container").outerHeight();$(window).on("resize load",function(){addel=$(".fixed-top-container").outerHeight();})}}
parentbox.css("min-height",height);if($(window).width()<=991){parentbox.css("min-height","auto");e.width("auto");e.css("position","sticky");}
$(window).on('load resize',function(){height=e.innerHeight();stickyEnd=parseInt(parentbox.height())+parentbox.offset().top;offsetTop=wpadminbar+floatingOffset+offset+addel;parenttop=parent.offset().top-offsetTop;e.width(parent.width());parentbox.css("min-height",height);parentwidth=parent.width();parentboxwidth=parentbox.width();})
function stickyposition(){if(parentwidth+30>=parentboxwidth){parentbox.css("min-height","auto");e.removeAttr("style");return false;}else{if($(window).scrollTop()>parenttop){height=e.innerHeight();stickyEnd=parseInt(parentbox.height())+parentbox.offset().top;parenttop=parent.offset().top-offsetTop;if($(window).scrollTop()>stickyEnd-height-offsetTop){e.css({"position":"relative","top":stickyEnd-(height+parenttop)-offsetTop,});}else{e.css({"position":"fixed","top":offsetTop});}}else{e.css({"position":"relative","top":"0"});}}}
$(window).on("scroll resize",function(){stickyposition();});stickyposition();});$(".fixed-top-container").each(function(){if(typeof DNNapplyTypography!="undefined"){return;}
var wpadminbar=$("#wpadminbar").length==0?0:$("#wpadminbar").height();var initFloating=floatingOffset;var e=$(this),parent=e.parent(),offset=e.data("offset")?e.data("offset"):0,offsetTop=wpadminbar+initFloating+offset,offsetLfet=e.offset().left,parenttop=parent.offset().top-offsetTop,height=e.outerHeight();e.width(e.width());if($(window).width()<=991){e.width("auto");e.css("position","sticky");}
$(window).on('load resize',function(){height=e.innerHeight();offsetTop=wpadminbar+initFloating+offset;parenttop=parent.offset().top-offsetTop;e.width(parent.width());parent.css("min-height",height);})
parent.css("min-height",height);function fixedBox(){if($(window).scrollTop()>parenttop){height=e.innerHeight();parenttop=parent.offset().top-offsetTop;e.css({"position":"fixed","top":offsetTop,"left":offsetLfet});floatingOffset=initFloating+height;}else{e.css({"position":"relative","top":0,"left":0});floatingOffset=initFloating;}}
$(window).on("scroll resize",function(){fixedBox();});fixedBox();})};DNG.anchorSmooth=function(){var OnePageOption=DNG.OnePageOption;var urlhref=window.location.pathname;var reg=/[~!@#$%^&*()/\|,.<>?"'();:=\[\]{}]/;var scrollbox=jQuery('body,html');var w=$(window);if($(".dng-main").data("page-type")=="verticalfullpage"){scrollbox=jQuery(".dng-main");w=jQuery(".dng-main");}
if(OnePageOption.duration){$(".primary_structure >li.current >a,.menu_list.mm-listview > li.current >a,.mobilemenu-main .gomenu>ul>li>a").each(function(){var h=$(this).attr("href");if(h==window.location.href.split("#")[0]||h.substring(0,h.length-1)==window.location.href.split("#")[0]){$(this).on("click",function(e){e.preventDefault();if($(this).parents(".mm-listview").length){$(".dng-mobilemenu .mobile-menu-icon").eq(0).click();}
scrollbox.stop().animate({scrollTop:0},($("html").css("scroll-behavior")=="smooth"?0:(OnePageOption.duration?OnePageOption.duration:500)),OnePageOption.easing);window.history.pushState({},0,h);return false;}).addClass("dng-anchor").attr("href","#Body")}})}else{var OnePageOption={duration:500,easing:"swing"};}
$('.content-builder,.header_bg,.mobile-header,.dng-leftmenu,.dng-megamenu,.dng-sidepanemenu,#anchorNav,.dng-mobilemenu,.mobilemenu-main .gomenu').find('a[href*="#"]:not(.mm-btn):not(.mm-next):not(.mm-title)').each(function(){if(typeof DNNapplyTypography!="undefined"){return;}
if(!$(this).hasClass("LightBox")&&!$(this).hasClass("is-lightbox")){if(!reg.test(this.hash.trim().substr(1))){var $target=this.hash&&this.hash!="#"?$(this.hash):false;var $hash=this.hash;var url=this.pathname;if($target.length&&url==urlhref){$(this).addClass('dng-anchor').on("click",function(e){e.preventDefault();var t=$target.offset().top;if($(".dng-main").data("page-type")=="verticalfullpage"){t=$target.offsetTopParent(scrollbox);}
scrollbox.stop().animate({scrollTop:t-floatingOffset},($("html").css("scroll-behavior")=="smooth"?0:(OnePageOption.duration?OnePageOption.duration:500)),OnePageOption.easing);if($hash!="#Body"){window.history.pushState(null,null,$hash);}});}}}})
function menuAnchorPosition(menu){var $current=menu.find('.dng-anchor').eq(0);var sibling=false;if(menu.hasClass("anchor-nav")){sibling=true}
if($current.length){sibling?$current.addClass("current"):$current.parent().addClass("current");}
w.on("scroll",function(){if(parseInt(w.scrollTop())+w.height()==parseInt($(document).height())){$current=menu.find('.dng-anchor').last();}else{menu.find('.dng-anchor').each(function(){var t=$(this.hash).offset().top;if($(".dng-main").data("page-type")=="verticalfullpage"){t=$(this.hash).offsetTopParent(scrollbox);}
if(w.scrollTop()>=t-floatingOffset-1){$current=$(this);}else{return false;}});}
if(w.scrollTop()==0){menu.find('.dng-anchor').eq(0);}
if(sibling){$current.addClass("current").siblings().removeClass("current");}else{$current.parents("ul").find("a[href*=#]").parent().removeClass("current");$current.parent().addClass("current");}})}
menuAnchorPosition($(".dng-leftmenu"));menuAnchorPosition($(".dng-megamenu"));menuAnchorPosition($(".dng-sidepanemenu"));menuAnchorPosition($("#anchorNav"));menuAnchorPosition($(".dng-mobilemenu"));menuAnchorPosition($(".mobilemenu-main .gomenu"));if(typeof DNNapplyTypography=="undefined"){menuAnchorPosition($(".anchor-nav"));}
function AnchorPosition(anchor){var $current=anchor.children('li').eq(0);$current.addClass("active").siblings().removeClass("active");function anchorscroll(){anchor.find('li > a').each(function(){var t=$(this.hash).offset().top;if($(".dng-main").data("page-type")=="verticalfullpage"){t=$(this.hash).offsetTopParent(scrollbox);}
if(w.scrollTop()>=t-floatingOffset-1){$current=$(this).parent("li");}else{return false;}});$current.addClass("active").siblings().removeClass("active");}
w.on("scroll",function(){anchorscroll();})
anchorscroll();}
AnchorPosition($(".anchor-link"));};DNG.editMode_panename=function(){$(".addModuleHandler").each(function(){$(this).parent().attr("id")&&$(this).after("<div class=\"edit-panename\">"+$(this).parent().attr("id").split("dnn_")[1]+"</div>")})};DNG.dngparallax=function(){$('[data-parallax="parallax"]').each(function(){if(typeof jQuery.fn.paroller=="function"){$(this).paroller();};$(window).trigger("scroll");$(this).addClass("parallax-load");})
$('[data-parallax="youtube"],[data-parallax="video"]').each(function(){var e=$(this);e.prepend('<div class="dng-video-wrapper"><div class="dng-video-responsive"></div></div>');var responsive=e.find(".dng-video-responsive");var box=e.find(".dng-video-wrapper");var offsetTop=e.offset().top;var boxheight=parseInt(e.height());if(e.data("parallax")=="youtube"){if(!e.data("url"))return false;var id='playerBox'+e.data("id");responsive.append('<div class="playerBox youtube-playerBox" id="'+id+'" style="width:300px;height:150px;"></div>')
if(!$("#youtube_iframe_api").length){var iframe=e.find(".playerBox").eq(0);var tag=document.createElement('script');tag.src="https://www.youtube.com/iframe_api";tag.id="youtube_iframe_api";var firstScriptTag=document.getElementsByTagName('script')[0];firstScriptTag.parentNode.insertBefore(tag,firstScriptTag);}
var player,play=false;window.onYouTubePlayerAPIReady=function(){var playerVars={controls:0,rel:0,showinfo:0,modestbranding:1,version:3,iv_load_policy:3,wmode:"transparent",playsinline:1,fs:0,disablekb:1,loop:0};if(e.data("loop"))playerVars["loop"]=1;if(e.data("muted"))playerVars["mute"]=1;if(e.data("start"))playerVars["start"]=e.data("start");if(e.data("end"))playerVars["end"]=e.data("end");player=new YT.Player(id,{videoId:e.data("url"),playerVars:playerVars,list:false,listType:false,events:{'onReady':onPlayerReady,'onStateChange':onPlayerStateChange,'onPlaybackQualityChange':onPlayerPlaybackQualityChange,}});function onPlayerReady(event){event.target.playVideo();if(e.data("viewport")){if(!play&&$(window).scrollTop()+parseInt($(window).height())>offsetTop&&$(window).scrollTop()<offsetTop+boxheight){event.target.playVideo();play=true;}else{event.target.pauseVideo();}
$(window).on("scroll",function(){if(!play&&$(window).scrollTop()+parseInt($(window).height())>offsetTop&&$(window).scrollTop()<offsetTop+boxheight){event.target.playVideo();play=true;}
if(play&&($(window).scrollTop()>offsetTop+boxheight||$(window).scrollTop()+parseInt($(window).height())<offsetTop)){event.target.pauseVideo();play=false;}})}
iframe=e.find(".playerBox").eq(0);count();}
function onPlayerStateChange(event){if(e.data("loop")){if(event.data==YT.PlayerState.ENDED){if(e.data("start")){player.seekTo(e.data("start"));}else{player.seekTo(0);}
player.playVideo();}}}
function onPlayerPlaybackQualityChange(event){}}}else{var html='<video playsinline class="playerBox"';if(e.data("loop"))html+=' loop';if(e.data("muted"))html+=' muted';if(!e.data("viewport"))html+=' autoplay';html+='>';if(e.data("mp4"))html+=' <source src="'+e.data("mp4")+'" type="video/mp4">';if(e.data("ogg"))html+=' <source src="'+e.data("ogg")+'" type="video/ogg">';if(e.data("webm"))html+=' <source src="'+e.data("webm")+'" type="video/webm">';html+='</video>';responsive.append(html)
var iframe=e.find(".playerBox").eq(0);iframe[0].addEventListener("loadedmetadata",function(){count();var play=false;if(e.data("viewport")){if(!play&&$(window).scrollTop()+parseInt($(window).height())>offsetTop&&$(window).scrollTop()<offsetTop+boxheight){iframe[0].play();play=true;}
$(window).on("scroll",function(){if(!play&&$(window).scrollTop()+parseInt($(window).height())>offsetTop&&$(window).scrollTop()<offsetTop+boxheight){iframe[0].play();play=true;}
if(play&&($(window).scrollTop()>offsetTop+boxheight||$(window).scrollTop()+parseInt($(window).height())<offsetTop)){iframe[0].pause();play=false;}})}else{iframe[0].play();}});}
function count(){iframe.attr({"width":iframe.width(),"height":iframe.height()}).css({"width":"100%","height":"100%"})
responsive.css("padding-bottom",(parseInt(iframe.attr("height"))/parseInt(iframe.attr("width"))*100+"%"))
var width=(parseInt(e.innerHeight())/parseInt(box.innerHeight()))*(parseInt(box.innerWidth())/parseInt(e.innerWidth()))*parseInt(e.innerWidth());box.innerWidth(width+2);$(window).on("resize",function(){width=(parseInt(e.innerHeight())/parseInt(box.innerHeight()))*(parseInt(box.innerWidth())/parseInt(e.innerWidth()))*parseInt(e.innerWidth());box.innerWidth(width+2);offsetTop=e.offset().top;boxheight=parseInt(e.height());})
$(window).load(function(){width=(parseInt(e.innerHeight())/parseInt(box.innerHeight()))*(parseInt(box.innerWidth())/parseInt(e.innerWidth()))*parseInt(e.innerWidth());box.innerWidth(width+2);offsetTop=e.offset().top;boxheight=parseInt(e.height());$(window).trigger("scroll");})}
$(this).addClass("parallax-load");})};DNG.sicoSVG=function(){$("i.sico").each(function(){if(!$(this).find("svg").length){var name=$(this).attr("class").split("sico ")[1]?.split(" ")[0];if(name===undefined){return true;}
$(this).append('<svg><use xlink:href="#'+name+'"></use></svg>')}})}
$(function(){DNG.OnePageOption=typeof OnePageOption!="undefined"?OnePageOption:{};DNG.fixedFooter();DNG.floatingNav();DNG.pageTitle();DNG.detailPageTitle();DNG.pageEndAnimating();DNG.sidebarSticky();DNG.anchorSmooth();DNG.editMode_panename();DNG.dngparallax();DNG.sicoSVG();});$(function(){$(window).on("load",function(){if($("body").hasClass("body-side-static-left")||$("body").hasClass("body-side-static-right")){setTimeout(function(){DNG.pageLoaders();},3000);}else{DNG.pageLoaders();}
if(typeof Main!="undefined"&&typeof Main.LightBoxPatch!="undefined")Main.LightBoxPatch();});});if(typeof ImgLoad!="undefined"){$(function(){ImgLoad(function(){DNG.pageLoaders();},$("body"))});}
setTimeout(function(){DNG.pageLoaders();},10000);})(jQuery);$('link[mediatitle="noneall"],link[media="none"]').each(function(){$(this).attr("media","all")})
$(".html5-video").each(function(){var e=$(this),btn=e.find(".video-play"),video=e.find("video")[0];btn.show().on("click",function(){video.play();})
video.addEventListener('play',function(){btn.hide();});video.addEventListener('pause',function(){btn.show();});video.addEventListener('ended',function(){btn.show();});})
$(".Login .userName > a").on("click",function(){$(this).siblings("ul").css("display")=="none"?$(this).siblings("ul").slideDown(200):$(this).siblings("ul").slideUp(200);return false;})
if($("body").hasClass("dnnEditState")){$(".BannerPane").before($(".overlay-panel-content"));$(function(){$(".BannerPane").after($(".side-panel-box"));});}
$(function(){$(".btn-plugin-import").on("click",function(){history.replaceState(null,'',location.pathname+location.search);})})
$(function(e){$('.is-arrow-down,.section-arrow-down').on('click',function(e){$('html,body').animate({scrollTop:$(this).parents(".is-section").offset().top+parseInt($(this).parents(".is-section").height())},($("html").css("scroll-behavior")=="smooth"?0:800));e.preventDefault();e.stopImmediatePropagation();return false;});$('.d-wrapper > div:first-child').find('.is-scale-animated').addClass('is-appeared');$('.is-scale-animated').appear();$('.is-scale-animated').on('appear',function(){$(this).addClass('is-appeared');});$('.is-scale-animated').on('disappear',function(){$(this).removeClass('is-appeared');});$('.is-animated').each(function(){$(this).addClass('animated');$(this).addClass('fadeOut');});});(function($){var selectors=[];var check_binded=false;var check_lock=false;var defaults={interval:250,force_process:false};var $window=$(window);var $prior_appeared=[];function process(){check_lock=false;for(var index=0,selectorsLength=selectors.length;index<selectorsLength;index++){var $appeared=$(selectors[index]).filter(function(){return $(this).is(':appeared');});$appeared.trigger('appear',[$appeared]);if($prior_appeared[index]){var $disappeared=$prior_appeared[index].not($appeared);$disappeared.trigger('disappear',[$disappeared]);}
$prior_appeared[index]=$appeared;}};function add_selector(selector){selectors.push(selector);$prior_appeared.push();}
$.expr.pseudos['appeared']=function(element){var $element=$(element);if(!$element.is(':visible')){return false;}
var window_left=$window.scrollLeft();var window_top=$window.scrollTop();var offset=$element.offset();var left=offset.left;var top=offset.top;if(top+$element.height()>=window_top&&top-($element.data('appear-top-offset')||0)<=window_top+$window.height()-200&&left+$element.width()>=window_left&&left-($element.data('appear-left-offset')||0)<=window_left+$window.width()){return true;}else{return false;}};$.fn.extend({appear:function(options){var opts=$.extend({},defaults,options||{});var selector=this.selector||this;if(!check_binded){var on_check=function(){if(check_lock){return;}
check_lock=true;setTimeout(process,opts.interval);};$(window).on('scroll',on_check).on('resize',on_check);check_binded=true;}
if(opts.force_process){setTimeout(process,opts.interval);}
add_selector(selector);return $(selector);}});$.extend({force_appear:function(){if(check_binded){process();return true;}
return false;}});})(function(){if(typeof module!=='undefined'){return require('jquery');}else{return jQuery;}}());function loadScript(url,callback){var script=document.createElement("script")
script.type="text/javascript";if(script.readyState){script.onreadystatechange=function(){if(script.readyState=="loaded"||script.readyState=="complete"){script.onreadystatechange=null;callback();}};}else{script.onload=function(){callback();};}
script.src=url;document.body.appendChild(script);}
$(function(){var tabsAnimation=false;function tabs(event){event.preventDefault();if(!tabsAnimation&&!$(this).hasClass("active")){$(this).addClass("active").attr("aria-selected","true").attr("tabindex","0").siblings().removeClass("active").attr("aria-selected","false").attr("tabindex","-1");var index=$(this).index();var box=$(this).parents(".section-tabs-list,.section-tabs-indexed").siblings(".section-tabs-container").find(".is-container").eq(index).attr("tabindex","0");if(box.parent(".section-tabs-container").data("effect")=="slide"){tabsAnimation=true;box.addClass("active in");box.siblings(".is-container.active").addClass("out").delay(300).queue(function(){$(this).hide().removeClass("active out in");$(this).dequeue();box.show().removeClass("in").delay(300).queue(function(){tabsAnimation=false;$(this).dequeue();});});box.parent(".section-tabs-container").animate({"height":box.innerHeight()},function(){$(this).height("");})}else{box.fadeIn().addClass("active").siblings(".is-container").hide().removeClass("active");}
$(window).trigger("scroll");if($(window).width()<768){jQuery('body,html').stop().animate({scrollTop:$(this).parent().offset().top-floatingOffset-30},($("html").css("scroll-behavior")=="smooth"?0:800));}}}
if(typeof DNNapplyTypography=="undefined"){$(".section-tabs-list .item,.section-tabs-indexed .item").on("click",tabs)}else{$(".d-wrapper").on("click",".section-tabs-list .item,.section-tabs-indexed .item",tabs)}
$(".section-tabs-list").on("keydown",function(event){var ev=event||window.event||arguments.callee.caller.arguments[0];var keyCode=ev.keyCode;if(keyCode==37){if($(this).find(":focus").prev().length){$(this).find(":focus").prev().trigger("focus").trigger("click");}else{$(this).find(".item").last().trigger("focus").trigger("click");}}else if(keyCode==39){if($(this).find(":focus").next().length){$(this).find(":focus").next().trigger("focus").trigger("click");}else{$(this).find(".item").first().trigger("focus").trigger("click");}}})})
$(window).on('load',function(){setTimeout(function(){$("html").scrollLeft(0);},100)})
$(function(){$("header.header_bg").append($(".btn-plugin.btn-plugin-headerlayout"))})
$(function(){$('.is-section[id][data-title]').each(function(){if($(this).attr("id")&&$(this).data("title")){$("#skip-menu ul").append('<li><a href="#'+$(this).attr("id")+'">'+$(this).data("title")+'</a></li>');$(this).attr("tabindex","-1");}})
var menulink=$("#skip-menu .menulink a");if(!$(menulink.attr("href")).length){menulink.parent(".menulink").remove();}else{$("#skip-menu .menulink").on("click",function(){jQuery('body,html').stop().animate({scrollTop:0},0);})}})
$(function(){if(typeof DNNapplyTypography=="undefined"){$(".builder-tab-title").each(function(){$(this).parents(".is-container,.is-section").eq(0).find(".builder-tab-cont").eq($(this).index()).before($(this).clone().addClass("mobile-show"));})}
if(typeof DNNapplyTypography!="undefined"||$(".builder-tab-title").length){$("#dnn_content").on("click",".builder-tab-title:not(.mobile-show)",function(event){event.preventDefault();var curbox=$(this).parents(".is-container").find(".builder-tab-cont").eq($(this).index());curbox.siblings(".builder-tab-cont").stop().fadeOut(100,function(){curbox.siblings(".builder-tab-cont").hide();curbox.stop().fadeIn();});$(this).addClass("active").siblings(".builder-tab-title").removeClass("active");})
$("#dnn_content").on("click",".builder-tab-title.mobile-show",function(event){event.preventDefault();var e=$(this);$(this).next(".builder-tab-cont").slideDown(function(){if(e.offset().top<$(window).scrollTop()){jQuery('body,html').stop().animate({scrollTop:e.offset().top-floatingOffset},200)}}).siblings(".builder-tab-cont").slideUp();$(this).addClass("active").siblings(".builder-tab-title").removeClass("active");})}})
$(function(){$(".languageBox").each(function(){var e=$(this);e.find(".language-current").on("click",function(event){event.preventDefault();var b=$(this);b.attr("aria-expanded",b.attr("aria-expanded")=="true"?"false":"true");e.find(".language-list").stop().fadeToggle();if(b.attr("aria-expanded")=="true"){e.find(".language-list a").eq(0).trigger("focus");}})
$(document).on("click",function(event){if(!e.is(event.target)&&e.has(event.target).length===0){e.find(".language-list").fadeOut(function(){e.find(".language-current").attr("aria-expanded","false");});}})
e.find("button,input,a").on("blur",function(){if(!e.is(":focus-within")){e.find(".language-list").fadeOut(function(){e.find(".language-current").attr("aria-expanded","false");});}})
if(!e.find(".language-list").find("a").length){e.addClass("no-list");}})})
$(function(){$(".search-popup-box").each(function(){var e=$(this);e.find('.NormalTextBox').attr('placeholder',e.data("placeholder"))
e.find(".icon").on("click",function(event){event.preventDefault();var b=$(this);b.toggleClass('active');b.attr("aria-expanded",b.attr("aria-expanded")=="true"?"false":"true");b.siblings('.popup-content').stop().fadeToggle(function(){if(b.attr("aria-expanded")=="true"){b.siblings('.popup-content').find("input").trigger("focus");}});})
$(document).on("click",function(event){if(!e.is(event.target)&&e.has(event.target).length===0){e.find(".icon").removeClass('active');e.find(".popup-content").stop().fadeOut(function(){e.find(".icon").attr("aria-expanded","false");});}})
e.find("button,input,a").on("blur",function(){if(!e.is(":focus-within")){e.find(".icon").removeClass('active');e.find(".popup-content").stop().fadeOut(function(){e.find(".icon").attr("aria-expanded","false");});}})})})
$(function(){var BodyHeightChange=new Event('BodyHeightChange');var $tar=document.getElementById('dnn_content');var MutationObserver=window.MutationObserver||window.webkitMutationObserver||window.MozMutationObserver;var recordHeight=0;var mutationObserver=new MutationObserver(function(mutations){let height=window.getComputedStyle($tar).getPropertyValue('height');if(height===recordHeight){return;}
recordHeight=height;if(window.dispatchEvent){window.dispatchEvent(BodyHeightChange);}else{window.fireEvent(BodyHeightChange);}})
mutationObserver.observe($tar,{childList:true,attributes:true,characterData:true,subtree:true})});$(function(){if(typeof IntersectionObserver=="function"){let observer=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.intersectionRatio>0&&entry.intersectionRatio<=1){entry.target.play();}else{entry.target.pause();}})},{threshold:[0,0.25,0.75,1]});$(".is-overlay-Video-bg video").each(function(){observer.observe(this);})}});jQuery(document).ready(function(){$(".Business13-ContactUsBox .form-html .btn-submit.btn-default").wrapInner("<span>").addClass("button-04 circle-white");$(".button-04").each(function(){var e=$(this);if(!e.find(".circle").length){e.append('<span class="circle"></span>');}
var animate=true;var Timeout=false;e.on("mouseenter",function(event){if(animate){e.find(".circle").css({"transform-origin":event.offsetX+"px "+(event.offsetY+(e.innerWidth()-e.innerHeight())/2)+"px",}).addClass("active");animate=false;Timeout=setTimeout(function(){animate=true},300);}}).on("mouseleave",function(event){if(animate){e.find(".circle").css({"transform-origin":event.offsetX+"px "+(event.offsetY+(e.innerWidth()-e.innerHeight())/2)+"px",}).removeClass("active");animate=false;Timeout=setTimeout(function(){animate=true},300);}else{e.find(".circle").removeClass("active");clearTimeout(Timeout);Timeout=setTimeout(function(){animate=true},300);}})})});
/** custom.js end*/


/** back top start*/


(function ($) {
	jQuery('#back-to-top').on("click", function() {
		jQuery('body,html').stop().animate({
			scrollTop: 0
		}, ($("html").css("scroll-behavior")=="smooth"?0:800));
	});
	var backtop = function() {
			if (Math.max.call(window.scrollTop, document.body.scrollTop, document.documentElement.scrollTop) > 245) {
				jQuery('#back-to-top').addClass("active");
			} else {
				jQuery('#back-to-top').removeClass("active");
			}
		};
	$(window).on('load', function() {
		backtop();
	});
	$(window).on("scroll",function() {
		backtop();
	});

	var share = jQuery('.fixed-widget-list .share');
	var shareout="";
	var shareList = share.nextAll("li:not(.backtop)");
	var length = shareList.length;
	 
		share.on("mouseover", function() { 
				if($(window).width()<=767) return false;
				$(this).addClass("active");
				shareList.each(function(i){
					$(this).stop().delay(40*(length-i)).queue(function(){$(this).addClass("active");$(this).dequeue();})
				})
			}).on("click", function() { 
				if(share.hasClass("active")){
					share.removeClass("active");
					shareList.each(function(i){
						$(this).stop().delay(40*i).queue(function(){$(this).removeClass("active");$(this).dequeue();})
					})
				}else{
					$(this).addClass("active");
					shareList.each(function(i){
						$(this).stop().delay(40*(length-i)).queue(function(){$(this).addClass("active");$(this).dequeue();})
					})
				}
			}).parent().on("mouseleave", function() {
				if($(window).width()<=767) return false;
				shareout = setTimeout(function(){
					share.removeClass("active");
					shareList.each(function(i){
						$(this).stop().delay(40*i).queue(function(){$(this).removeClass("active");$(this).dequeue();})
					})
				},300)
			}).on("mouseenter", function() {
				shareout && clearInterval(shareout);
			});

})(jQuery);

/** back top end*/

